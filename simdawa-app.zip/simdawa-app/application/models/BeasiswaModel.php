<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BeasiswaModel extends CI_Model {
    private $table = "beasiswa";

    public function get_beasiswa()
    { 
        return $this->db->get($this->table)->result();
    }

    public function insert_beasiswa()
    {
        $data = [
            'nama_beasiswa' => $this->input->post('nama_beasiswa'),
            'keterangan' => $this->input->post('keterangan')
        ];
        $this->db->insert($this->table, $data);
    }

    public function get_beasiswa_byid($id){
    
        return $this->db->get_where($this->table, ['id' => $id])->row();
    }

    public function update_beasiswa(){
        $data = [
            'nama_beasiswa' => $this->input->post('nama_beasiswa'),
            'keterangan' => $this->input->post('keterangan')
        ];
        $this->db->where('id', $this->input->post('id'));
        $this->db->update($this->table, $data);
    }
    public function delete_beasiswa($id){
        $this->db->where('id', $id);
        $this->db->delete($this->table);
    }
}
